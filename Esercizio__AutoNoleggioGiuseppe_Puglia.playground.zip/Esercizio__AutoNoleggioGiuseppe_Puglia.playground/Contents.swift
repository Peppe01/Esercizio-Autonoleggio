import UIKit

print("Esercizio Auto Noleggio")
print()

class Auto{
    var codice: String
    var prenotata: Bool = false
    
    init(codice: String, prenotata: Bool) {
        self.codice = codice
        self.prenotata = prenotata
    }
}

class AutoNoleggio{
    var listAuto: [Auto] = []
    var rata: Int = 50
    
    //Proprietà GET
    var autoDisponibile: Int {
        var count: Int = 0
        
        for auto in self.listAuto{
            if auto.prenotata == false{
                count += 1
            }
        }
        return count
    }
    
    init (listAuto: [Auto]){
        self.listAuto = listAuto
    }
    
    func autoNoleggiate(giorni: Int?) {
        for auto in self.listAuto{
            if auto.prenotata == false {
                auto.prenotata = true
                if let giorni = giorni{
                    print("L'Auto: \(auto.codice) è prenotata per \(giorni) giorni, al prezzo di \(self.rata * giorni) al giorno.")
                }
                return
            }
        }
        print("Non ci sono auto disponibili")
    }
}
var auto1 = Auto.init(codice: "ABC123", prenotata: false)
var auto2 = Auto.init(codice: "QUI010", prenotata: false)
var auto3 = Auto.init(codice: "FLEX01", prenotata: false)
var autoNoleggio = AutoNoleggio.init(listAuto: [auto1, auto2, auto3])
print("Le auto disponibili sono \(autoNoleggio.autoDisponibile).")
autoNoleggio.autoNoleggiate(giorni: 15)
autoNoleggio.autoNoleggiate(giorni: 10)
autoNoleggio.autoNoleggiate(giorni: 30)
autoNoleggio.autoNoleggiate(giorni: nil)

